<?php

return array(
    'TITLE_FONT_COLOR' => array(
        '#5674ed' => '蓝色',
        '#ed568b' => '红色',
    ),
    'COPY_FROM' => array(
        0 => '本站',
        1 => '新浪网',
        2 => '央视网',
        3 => '网易',
        4 => '搜狐',

    ),
);